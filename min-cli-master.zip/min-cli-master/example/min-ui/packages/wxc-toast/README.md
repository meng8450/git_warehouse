# wxc-toast

> MinUI 小程序组件 - 提示

## Install

``` bash
$ min install wxc-toast
```


## API

### Toast

| 名称                  | 描述                         |
|----------------------|------------------------------|
|`prop-name`           | 描述属性的类型，默认值等         |
|`method-name`         | 描述方法的参数，返回值等         |

## ChangeLog

#### v1.0.0（2017-12-12）

- 初始版本
