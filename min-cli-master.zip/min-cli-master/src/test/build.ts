import build from '../cli/build'

build.action({
  watch: true,
  page: ''
})
