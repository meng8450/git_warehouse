import changelog from '../cli/changelog'

changelog.action({})
