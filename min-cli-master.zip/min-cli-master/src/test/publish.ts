import publish from '../cli/publish'

publish.action('loading', {})
