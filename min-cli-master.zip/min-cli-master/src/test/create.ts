import $new from '../cli/new'

$new.action('test', {
  title: '测试'
})
