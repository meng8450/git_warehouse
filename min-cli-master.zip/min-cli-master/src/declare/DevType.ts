export interface DevType {
  deploy: string
  framework: string
  project: string
  platform: string
}
