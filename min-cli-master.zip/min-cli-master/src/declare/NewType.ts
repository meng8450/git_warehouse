/**
 * 新建类型
 *
 * @export
 * @enum {number}
 */
export enum NewType {
  Package = 'package',
  Page = 'page'
}
