export enum CompileType {
  // TEMPLATE

  // SCRIPT

  // STYLE
  LESS = 'LESS',
  PCSS = 'PCSS'
}
